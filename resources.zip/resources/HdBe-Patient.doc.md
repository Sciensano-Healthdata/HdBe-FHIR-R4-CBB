## zib Patient difference

| Concept         | Category          | Description                             | 
|-----------------|-------------------|-----------------------------------------|
|`patient_identification_number` | textual | Replaced the Dutch context (BSN) with the Belgian equivalent (NISS-INSZ). |
|`gender` | textual | Extended definition to clarify that the concept is about administrative gender rather then the patient's identified sex.  |
|`multiple_birth_order` | element | Added mapping to mulitple birth order.|