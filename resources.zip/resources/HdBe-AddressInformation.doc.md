## zib AddressInformation difference

| Concept         | Category          | Description                             | 
|-----------------|-------------------|-----------------------------------------|
|`city` | textual | Removed Dutch context.|
|`district` | textual | Removed Dutch context. |
|`postalCode` | textual | Removed Dutch context. |
|`country.extension:countryCode.value[x]` | terminology | Replaced valueSet LandCodelijsten with CountryISO. |
